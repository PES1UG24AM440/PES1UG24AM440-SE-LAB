# Static Code Analysis Issues — Wildlife Sightings

## Completed issue table

| Issue | Type / Tool | Original line(s) | Description / Impact | Fix applied |
|---|---|---:|---|---|
| SQL query built with string formatting | Security — Bandit B608 (Medium) | 9 | Inserting `species` and `zone` directly into an SQL string could allow SQL injection if values contain malicious SQL. | Replaced string-built SQL with a parameterized query using placeholders and bound values. |
| MD5 used to generate observer ID | Security — Bandit B324 (High) | 15 | MD5 is considered weak for security-sensitive hashing and can create a false impression of secure identification. | Replaced MD5 with a stronger hash algorithm for the observer identifier. The identifier is still a short display ID, not an authentication mechanism. |
| `assert` used for a runtime check | Reliability / Security — Bandit B101 (Low) | 36 | Assertions can be removed when Python runs with optimization, so they should not enforce required runtime behavior. | Replaced the assertion with an explicit conditional check / exception. |
| Mutable default argument `extras={}` | Code quality — Pylint W0102 | 8 | The same dictionary can be reused across function calls, potentially carrying data between calls unexpectedly. | Changed the default to `None` and initializes a new dictionary inside the function when needed. |
| Missing module docstring | Maintainability — Pylint C0114 | 1 | The module's purpose was not documented. | Added a module-level docstring describing the wildlife-sightings script. |
| Missing function docstrings | Maintainability — Pylint C0116 | 8, 14, 18, 26, 32 | Functions did not explain their purpose or parameters/return values. | Added concise docstrings to the functions. |
| Function names not in `snake_case` | Style — Pylint C0103 | 8, 14, 18 | Names such as `logSighting`, `observerId`, and `zoneSummary` did not follow Python naming conventions. | Renamed functions to `log_sighting`, `observer_id`, and `zone_summary`. |
| Lines exceeded the recommended length | Style — Flake8 E501 / Pylint C0301 | 5, 9, 19, 27, 28 | Long lines made the source harder to scan and violated configured style limits. | Wrapped long expressions and SQL statements across multiple lines. |
| Ambiguous variable name `l` and missing operator spacing | Style — Flake8 E741, E225 | 28 | The single-letter `l` can be confused with `1`, and the expression lacked whitespace around an operator. | Replaced the variable with a descriptive name and corrected spacing. |
| Unnecessary `else` after `return` | Code quality — Pylint R1705 | 20 | An `else` branch after a `return` adds unnecessary nesting. | Removed the redundant `else` and de-indented its body. |
| Function parameters shadowed outer-scope `conn` | Code quality — Pylint W0621 | 8, 18, 26 | Reusing the name `conn` in function parameters triggered scope warnings and reduced clarity. | Refactored the function/connection naming to avoid shadowing the outer-scope variable. |
| Missing final newline | Style — Flake8 W292 / Pylint C0304 | End of file | The file did not end with a newline, which violates standard text-file formatting. | Added a final newline. |

## Verification results

| Check | Before | After |
|---|---|---|
| Bandit | 3 findings: 1 High, 1 Medium, 1 Low | No issues identified; 0 High, 0 Medium, 0 Low |
| Flake8 | Multiple line-length, naming/spacing, and end-of-file findings | Clean output after fixes |
| Pylint | 3.46/10 | 10.00/10 |

## Commits

1. `11adecb` — `fix(security): resolve Bandit SQL injection, MD5, and assert findings`
2. `98630e4` — `style(pep8): fix Flake8 line lengths, spacing, and variable naming`
3. `528d6f4` — `refactor(pylint): add docstrings, fix mutable default, and resolve scope warnings`

