"""Module for recording and querying wildlife sightings in zones."""

import hashlib
import sqlite3


def log_sighting(db_conn, species, zone, count, extras=None):
    """Log an animal sighting and update running totals."""
    if extras is None:
        extras = {}
    query = (
        "INSERT INTO sightings (species, zone, count) "
        "VALUES (?, ?, ?)"
    )
    db_conn.execute(query, (species, zone, count))
    extras[species] = extras.get(species, 0) + count
    return extras


def observer_id(observer):
    """Generate a shortened observer identifier."""
    return hashlib.md5(
        observer.encode(), usedforsecurity=False
    ).hexdigest()[:6]


def zone_summary(db_conn, zone):
    """Calculate the total sightings recorded in a given zone."""
    query = "SELECT SUM(count) FROM sightings WHERE zone = ?"
    row = db_conn.execute(query, (zone,)).fetchone()
    if row[0] is None:
        return 0
    return row[0]


def rarest(db_conn):
    """Return the species with the minimum total sightings."""
    query = "SELECT species, SUM(count) FROM sightings GROUP BY species"
    rows = db_conn.execute(query).fetchall()
    least_common = min(rows, key=lambda r: r[1])
    return least_common[0]


def main():
    """Initialize database, run sightings test cases, and print summary."""
    db_conn = sqlite3.connect(":memory:")
    db_conn.execute(
        "CREATE TABLE sightings ("
        "id INTEGER PRIMARY KEY, species TEXT, zone TEXT, count INTEGER)"
    )

    totals = log_sighting(db_conn, "Leopard", "North", 1)
    log_sighting(db_conn, "Chital", "North", 24, totals)
    log_sighting(db_conn, "Hornbill", "East", 3, totals)

    if len(totals) != 3:
        raise AssertionError("Totals check failed")

    print(
        observer_id("Arun"),
        zone_summary(db_conn, "North"),
        rarest(db_conn),
    )


if __name__ == "__main__":
    main()
