# Reflection — Lab 5: Static Code Analysis

## 1. What is static code analysis, and why is it useful?

Static code analysis examines source code without executing the program. It helps identify possible security vulnerabilities, maintainability problems, and style violations early. In this lab, the tools found issues that might not be obvious from simply running the wildlife-sightings program.

## 2. What did Pylint, Bandit, and Flake8 each help identify?

- **Pylint** highlighted maintainability and code-quality problems, including missing docstrings, non-standard function names, a mutable default argument, scope warnings, and an unnecessary `else` after `return`.
- **Bandit** identified security-related patterns: SQL built through string formatting (B608), use of MD5 (B324), and use of `assert` for a check (B101).
- **Flake8** identified PEP 8 formatting issues, including long lines, an ambiguous variable name, missing operator whitespace, and a missing final newline.

The tools overlap in some areas, but each provides a different perspective on code quality.

## 3. Which issue was most important, and why?

The SQL injection warning was particularly important because directly inserting input values into an SQL statement can allow the query to be altered. Parameterized SQL keeps the query structure separate from the values supplied to it. The MD5 finding was also important because MD5 should not be treated as a secure hash for security-sensitive uses.

## 4. What changes were made to the program?

The code was updated to use parameterized SQL, replace MD5 with a stronger hash, avoid relying on `assert` for a required check, remove the mutable dictionary default, add docstrings, follow `snake_case` naming, simplify control flow, fix long lines and spacing, use clearer variable names, and add the final newline.

## 5. How were the fixes verified?

The static-analysis tools were run again after the changes. Bandit reported **no issues identified**, Flake8 produced clean output, and Pylint improved from **3.46/10 to 10.00/10**. The program was also run from the terminal and printed a wildlife-sighting result (`5455c3 25 Leopard`), providing a basic check that it still executed.

## 6. What did you learn from this lab?

I learned that a program can run successfully and still contain security, maintainability, or style problems. Static-analysis tools make these problems easier to detect and provide actionable messages that help prioritize fixes. I also learned that small practices—such as parameterized SQL, safe default arguments, descriptive names, docstrings, and consistent formatting—make code safer and easier for other developers to understand.

## 7. What would you do differently in a future project?

I would run Pylint, Bandit, and Flake8 regularly during development instead of waiting until the end. I would also include these checks in a CI workflow so issues are caught before changes are merged. Finally, I would review each warning rather than blindly suppressing it, and add automated tests for important behavior such as database inserts and summary calculations.

## 8. What are the limitations of static analysis?

Static analysis can flag suspicious patterns that are not necessarily exploitable, and it cannot prove that the application is completely secure or correct. It may also miss problems that depend on runtime data or the wider environment. Therefore, static analysis should be combined with tests, code review, and appropriate security practices.

